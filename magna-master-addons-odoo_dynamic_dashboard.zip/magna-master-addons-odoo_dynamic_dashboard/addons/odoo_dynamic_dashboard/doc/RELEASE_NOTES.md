
## Module <odoo_dynamic_dashboard>

#### 14.12.2021
#### Version 14.0.1.0.0

##### Initial Commit for odoo_dynamic_dashboard

