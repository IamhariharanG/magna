from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Manufactureordersinherits(models.Model):
    _inherit="mrp.production"

    count_purchase=fields.Integer(string="Purchase Count",compute='purchases_counts')

    def purchases_counts(self):
        for rec in self:
            purchase_orm=self.env['purchase.order'].search([('manufacture_order','=',rec.name)])
            self.count_purchase = len(purchase_orm) 

    def get_purchases_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase',
            'view_mode': 'tree,form',
            'res_model': 'purchase.order',
            'domain': [('manufacture_order', '=', self.name)],
            'context': "{'create': False}"
        }     

    def manufacturing_to_wizard(self):
        for rec in self:    
            wizard = self.env['wizard.purchase'].create({'order_date':rec.date_planned_start,'manufacture_order':rec._origin.id})
            line_val = [(5, 0, 0)]
            for line in rec.move_raw_ids:
                line = (0, 0, {
                         'product_id': line.product_id.id,
                         'product_uom': line.product_uom.id,
                         'product_uom_qty':line.product_uom_qty,
                         })
                line_val.append(line)
            wizard.wizard_lines = line_val
            return {
                'name': 'Create Purchase Order',
                'type': 'ir.actions.act_window',
                'res_model': 'wizard.purchase',
                'view_mode': 'form',
                'target': 'new',
                'res_id': wizard.id,
                'context': "{'create': True}",
                
            }
    