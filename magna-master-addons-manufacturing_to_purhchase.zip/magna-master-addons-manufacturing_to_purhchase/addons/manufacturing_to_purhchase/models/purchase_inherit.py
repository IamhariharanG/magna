from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Purcahseorderinherits(models.Model):
    _inherit="purchase.order"

    manufacture_order=fields.Many2one('mrp.production',string="Manufacture Order")
