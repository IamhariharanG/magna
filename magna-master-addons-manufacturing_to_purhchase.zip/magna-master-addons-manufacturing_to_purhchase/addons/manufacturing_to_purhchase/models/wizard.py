from odoo import fields, models

from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from openerp.exceptions import ValidationError

class Manufacturingtowizard(models.Model):
    _name = "wizard.purchase"

    order_date=fields.Datetime(string="Order Date")
    manufacture_order=fields.Many2one('mrp.production',string="Manufacture Order")
    partner_id=fields.Many2one('res.partner', string='Vendor', domain="[('supplier_rank','>',0)]", help="You can find a vendor by its Name, TIN, Email or Internal Reference.")
    
    wizard_lines=fields.One2many('wizard.purchase.line','wizard_id',string='Wizard',ondelete='cascade')

    def wizard_to_purchase(self):
        for rec in self:    
            purchase = self.env['purchase.order'].create({'partner_id':rec.partner_id.id,'manufacture_order': rec.manufacture_order.id})
            line_val = [(5, 0, 0)]
            for line in rec.wizard_lines:
                line = (0, 0, {
                        'product_id': line.product_id.id,
                        'product_qty': line.product_uom_qty,
                        'product_uom': line.product_uom.id,
                        })
                line_val.append(line)
            purchase.order_line = line_val
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'purchase.order',
                'view_mode': 'form',
                'res_id': purchase.id,
                'context': "{'create': True}",
                
            }


class manufacturinglinetowizard(models.Model):
    _name ="wizard.purchase.line"

    wizard_id = fields.Many2one('wizard.purchase', String="Wizard")
    product_id =fields.Many2one("product.product",string="Products",ondelete='cascade')
    product_uom_qty = fields.Float("Quantity")
    product_uom=fields.Many2one('uom.uom',string='UoM',related='product_id.uom_id')
    
    sale_id=fields.Many2one('sale.order',string="Sale Order")
