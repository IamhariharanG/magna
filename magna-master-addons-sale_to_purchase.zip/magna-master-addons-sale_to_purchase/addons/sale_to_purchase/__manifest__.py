{
    'name': 'Sale Order to Purchase Order',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Sale Order to Purchase Order',
    'depends': ['base','sale','purchase'],
    'data': [
          'views/sale_inherit.xml',
          'views/purchase_inherit.xml',
          'views/product_wizard.xml',
          'security/ir.model.access.csv',
         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
