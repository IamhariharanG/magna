from odoo import fields, models

from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from openerp.exceptions import ValidationError

class Saletowizard(models.Model):
    _name = "wizard.wizard"

    partner_id=fields.Many2one('res.partner', string='Vendor', domain="[('supplier_rank','>',0)]", help="You can find a vendor by its Name, TIN, Email or Internal Reference.")
    scheduled_date=fields.Datetime(string="Scheduled Date")
    sale_id=fields.Many2one('sale.order',string="Sale Order")
    wizard_line=fields.One2many('wizard.wizard.line','wizard_id',string='Wizard',ondelete='cascade')

    def wizard_to_purchase(self):
        for rec in self:
            purchase = self.env['purchase.order'].create({'partner_id':rec.partner_id.id,'sale_id': rec.sale_id.id,'date_planned':rec.scheduled_date})
            line_val = [(5, 0, 0)]
            for line in rec.wizard_line:
                line = (0, 0, {
                        'product_id': line.product_id.id,
                        'name' : line.description,
                        'product_qty': line.product_uom_qty,
                        'price_unit': line.price_unit,
                        'price_subtotal':line.subtotal, 
                        })
                line_val.append(line)
            purchase.order_line = line_val
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'purchase.order',
                'view_mode': 'form',
                'res_id': purchase.id,
                'context': "{'create': True}",
                
            }


class saleorderlinewizard(models.Model):
    _name = "wizard.wizard.line"

    wizard_id = fields.Many2one('wizard.wizard', String="Wizard")

    product_id =fields.Many2one("product.product",string="Products",ondelete='cascade')
    description =fields.Text("Description")
    product_uom_qty = fields.Float("Quantity")
    price_unit=fields.Float(string="Unit Price")
    subtotal = fields.Monetary("Subtotal")
    company_id = fields.Many2one('res.company', 'Company',default=lambda self:self.env.user.company_id.id, index=1)
    currency_id = fields.Many2one('res.currency', 'Currency',default=lambda self: self.env.user.company_id.currency_id.id,required=True)
  