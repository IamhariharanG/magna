{
    'name': 'Sale Order to Manufacturing Order',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Sale Order to Manufacturing Order',
    'depends': ['base','sale','purchase'],
    'data': [
          'security/ir.model.access.csv',
          'views/product_wizard.xml',
          'views/sale_inherit.xml',
          'views/manufacturing.xml',
         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
