from odoo import fields, models

from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from openerp.exceptions import ValidationError

class SaletoManufacturingwizard(models.Model):
    _name = "wizard.manufacture"

    order_date=fields.Datetime(string="Order Date")
    sale_id=fields.Many2one('sale.order',string="Sale Order")
    wizards_line=fields.One2many('wizard.manufacture.line','wizard_id',string='Wizard',ondelete='cascade')

    def wizard_to_manufacturing(self):
        for rec in self.wizards_line:    
            manufacture = self.env['mrp.production'].create({'sale_id':rec.sale_id.id,'date_planned_start':self.order_date,'product_id':rec.product_id.id,'product_qty':rec.product_uom_qty,'product_uom_id':rec.product_uom.id})
   
class saleorderlinemanufacturewizard(models.Model):
    _name ="wizard.manufacture.line"

    wizard_id = fields.Many2one('wizard.manufacture', String="Wizard")
    product_id =fields.Many2one("product.product",string="Products",ondelete='cascade')
    product_uom_qty = fields.Float("Quantity")
    product_uom=fields.Many2one('uom.uom',string='UoM')
    sale_id=fields.Many2one('sale.order',string="Sale Order")
