from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Saleorderinherit(models.Model):
    _inherit="sale.order"

    manufacturing_count=fields.Integer(string="Manufacturing Count",compute='manufacturing_counts')

    def manufacturing_counts(self):
        for rec in self:
            manufacturing_orm=self.env['mrp.production'].search([('sale_id','=',rec.name)])
            self.manufacturing_count = len(manufacturing_orm) 

    def get_manufacturing_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Manufacturing',
            'view_mode': 'tree,form',
            'res_model': 'mrp.production',
            'domain': [('sale_id', '=', self.name)],
            'context': "{'create': False}"
        }          

    def sale_to_manufacturing_wizard(self):
        for rec in self:    
            wizard = self.env['wizard.manufacture'].create({'order_date':rec.date_order})
            line_val = [(5, 0, 0)]
            for line in rec.order_line:
                line = (0, 0, {
                        'product_id': line.product_id.id,
                        'product_uom_qty': line.product_uom_qty,
                        'product_uom': line.product_uom.id,
                        'sale_id':self._origin.id,
                        })
                line_val.append(line)
            wizard.wizards_line = line_val
            return {
                'name': 'Create Manufacturing Order',
                'type': 'ir.actions.act_window',
                'res_model': 'wizard.manufacture',
                'view_mode': 'form',
                'target': 'new',
                'res_id': wizard.id,
                'context': "{'create': True}",
                
            }
    
        
           
    
        
