from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Manufactureorderinherit(models.Model):
    _inherit="mrp.production"

    sale_id=fields.Many2one('sale.order',string="Sale Order")

   