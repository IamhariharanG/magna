{
    'name': 'Sale Order to Project',
    'version': '14.0.0.1',
    'category': 'Tools',
    'summary': 'Sale Order to Project',
    'depends': ['base','sale','purchase'],
    'data': [
          'security/ir.model.access.csv',
          'views/product_wizard.xml',
          'views/sale_inherit.xml',
          'views/project_inherit.xml',
          'views/project_task_inherit.xml',
          'views/wizard_purchase.xml',
          'views/purchase_inherit.xml',

         
    ],
   'images':['static/description/icon.png'],
    'demo': [
    ],
    'css': [],
    'author': "Scopex pvt.ltd,Hariharan.G",
    'installable': True,
    'auto_install': False,
    'application': True,
}
