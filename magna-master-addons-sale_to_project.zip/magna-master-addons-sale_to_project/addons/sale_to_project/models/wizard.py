from odoo import fields, models

from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from openerp.exceptions import ValidationError

class Saletoprojectwizard(models.Model):
    _name = "wizard.project"

    assigned_date=fields.Datetime(string="Assigned Date")
    sale_id=fields.Many2one('sale.order',string="Sale Order")
    project=fields.Char(string='Project Name')


    # wizards_line=fields.One2many('wizard.project.line','wizard_id',string='Wizard',ondelete='cascade')

    def wizard_to_project(self):
        for rec in self:    
            project = self.env['project.project'].create({'sale_id':rec.sale_id.id,'assigned_date':rec.assigned_date,'name':rec.project})
   
# class saleorderlineprojectwizard(models.Model):
#     _name ="wizard.project.line"

#     wizard_id = fields.Many2one('wizard.project', String="Wizard")
#     product_id =fields.Many2one("product.product",string="Products",ondelete='cascade')
#     product_uom_qty = fields.Float("Quantity")
#     product_uom=fields.Many2one('uom.uom',string='UoM')
#     sale_id=fields.Many2one('sale.order',string="Sale Order")
