from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Saleorderinherit(models.Model):
    _inherit="sale.order"

    project_count=fields.Integer(string="Project Count",compute='project_counts')
    number2words=fields.Integer(string=" num 2 words")

    def project_counts(self):
        for rec in self:
            project_orm=self.env['project.project'].search([('sale_id','=',rec.name)])
            self.project_count = len(project_orm) 

    def get_project_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Projects',
            'view_mode': 'tree,form',
            'res_model': 'project.project',
            'domain': [('sale_id', '=', self.name)],
            'context': "{'create': False}"
        }          

    def sale_to_projectwizard(self):
        for rec in self:    
            wizard = self.env['wizard.project'].create({'assigned_date':rec.date_order,'sale_id':rec._origin.id})
            return {
                'name': 'Create Project',
                'type': 'ir.actions.act_window',
                'res_model': 'wizard.project',
                'view_mode': 'form',
                'target': 'new',
                'res_id': wizard.id,
                'context': "{'create': True}",
                
            }
    
        
           
    
        
