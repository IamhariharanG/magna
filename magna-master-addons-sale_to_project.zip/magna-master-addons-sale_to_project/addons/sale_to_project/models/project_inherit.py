from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Projectinherit(models.Model):
    _inherit="project.project"

    sale_id=fields.Many2one('sale.order',string="Sale Order")
    assigned_date=fields.Datetime(string="Order Date")

    purchase_count=fields.Integer(string="Purchase Count",compute='purchase_counts')
    project_no = fields.Char(string='No')
    start_date = fields.Date(string="Project Start Date")
    end_date = fields.Date(string="Project End Date")
    status_id = fields.Selection([('un_approved','Un-Approved'),('approved','Approved'),('cancelled','Cancelled')])
    sales_person = fields.Many2one('res.users',string="Sales Person")

    @api.model
    def create(self,vals):
        vals['project_no'] = self.env['ir.sequence'].next_by_code('project.sequence')
        result = super(Projectinherit,self).create(vals)
        return result
    
    
    def purchase_counts(self):
        for rec in self:
            purchase_orm=self.env['purchase.order'].search([('project_id','=',rec.name)])
            self.purchase_count = len(purchase_orm) 

    def get_purchases_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase',
            'view_mode': 'tree,form',
            'res_model': 'purchase.order',
            'domain': [('project_id', '=', self.name)],
            'context': "{'create': False}"
        }          
   