from odoo import fields, models, api
from datetime import date, datetime,timedelta
from odoo.exceptions import ValidationError


class Projecttaskinherit(models.Model):
    _inherit="project.task"

    sale_id=fields.Many2one('sale.order',string="Sale Order",related='project_id.sale_id')

    purchase_count=fields.Integer(string="Purchase Count",compute='purchase_counts')

    def purchase_counts(self):
        for rec in self:
            purchase_orm=self.env['purchase.order'].search([('project_task_id','=',rec.name)])
            self.purchase_count = len(purchase_orm) 

    def get_purchase_button(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase',
            'view_mode': 'tree,form',
            'res_model': 'purchase.order',
            'domain': [('project_task_id', '=', self.name)],
            'context': "{'create': False}"
        }          

    def task_to_wizard(self):
        for rec in self:   
            wizard = self.env['wizard.task'].create({'project_task_id': rec._origin.id,'project_id':rec.project_id.id})
            return {
                'name': 'Create Purchase Order',
                'type': 'ir.actions.act_window',
                'res_model': 'wizard.task',
                'view_mode': 'form',
                'target': 'new',
                'res_id': wizard.id,
                'context': "{'create': True}",
                
            }
    