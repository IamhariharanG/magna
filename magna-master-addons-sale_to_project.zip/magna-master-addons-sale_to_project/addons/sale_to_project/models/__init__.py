from . import sale_inherit
from . import wizard
from . import project_inherit
from . import project_task_inherit
from . import wizard_purchase
from . import purchase_inherit
