from odoo import fields, models

from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from openerp.exceptions import ValidationError

class projecttopurchase(models.Model):
    _name = "wizard.task"

    assigned_date=fields.Datetime(string="Assigned Date")
    sale_id=fields.Many2one('sale.order',string="Sale Order")
    project_id=fields.Many2one('project.project',string='Project Name')
    project_task_id=fields.Many2one('project.task',string='Project Task Name')
    partner_id=fields.Many2one('res.partner', string='Vendor', domain="[('supplier_rank','>',0)]", help="You can find a vendor by its Name, TIN, Email or Internal Reference.")
   

    wizards_line=fields.One2many('wizard.task.line','wizard_id',string='Wizard',ondelete='cascade')

    def project_wizard_to_purchase(self):
        for rec in self:    
            project = self.env['purchase.order'].create({'project_id':rec.project_id.id,'project_task_id':rec.project_task_id.id,'partner_id':rec.partner_id.id})
            line_val = [(5, 0, 0)]
            for line in rec.wizards_line:
                line = (0, 0, {
                        'product_id': line.product_id.id,
                        'product_qty': line.product_uom_qty,
                        'price_unit': line.product_uom.id,
                        })
                line_val.append(line)
            project.order_line = line_val
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'purchase.order',
                'view_mode': 'form',
                'res_id': project.id,
                'context': "{'create': True}",
                
            }
class projectpurchaseline(models.Model):
    _name ="wizard.task.line"

    wizard_id = fields.Many2one('wizard.task', String="Wizard")
    product_id =fields.Many2one("product.product",string="Products",ondelete='cascade')
    product_uom_qty = fields.Float("Quantity")
    product_uom=fields.Many2one('uom.uom',string='UoM',related='product_id.uom_id')
