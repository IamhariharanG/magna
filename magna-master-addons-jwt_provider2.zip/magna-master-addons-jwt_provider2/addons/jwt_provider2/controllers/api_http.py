# -*- coding: utf-8 -*-
from sqlite3 import DatabaseError
import werkzeug
from odoo import http
from odoo.http import request
from odoo.addons.auth_signup.models.res_users import SignupError
from ..JwtRequest import jwt_request
from ..util import is_valid_email
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import datetime
from datetime import timedelta,date
import base64
import jwt
import ast
import json
import random
import logging
import requests
_logger = logging.getLogger(__name__)

SENSITIVE_FIELDS = ['password', 'password_crypt', 'new_password', 'create_uid', 'write_uid']
SECRET_KEY = "6+8RpZ7ccvF1mPnCV4MDL7/ROLEIBp4f3hqRhvOeTx4="


class JwtController(http.Controller):

    @http.route('/api/http/hello', type='http', auth='public', csrf=False, cors='*')

    @jwt_request.middlewares('api_key')
    def hello(self, **kw):
        return jwt_request.response({ 'message': 'hello!', 'key_info': jwt_request.data.get('key_info') })

    @http.route('/api/http/login', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def login(self, email=None, password=None, **kw):
        email = request.params.get('email')
        password = request.params.get('password')
        token = jwt_request.login(email, password)

        login_email = request.env['res.users'].sudo().search([('login', '=', email)])
        if login_email:
            if token:
                login_orm = request.env['res.users'].sudo().search([('login', '=', email)])

                res = {
                "accessToken": token,
                "status": "success",
                "message": "Login Successfully",
                'status_message':"success",

                'data': {
                    'email':login_orm['email'],

                    'name':login_orm['name'],
                    'partner_id':login_orm['partner_id'].id,
                    'employee_id': login_orm['employee_id'].id,
                    'user_id':login_orm.id,
                }
                }
                return res
                
            else:
                res={
                    'status':"failure",
                    'message':"Invalid Email Or Password",
                    'status_message':"invalid"
                }
                return res
        else:
            res={
                'status':"failure",
                'message':"You have not Registered, Please Register.",
                'status_message':"notfound"

            }
            return res


    @http.route('/api/http/me', type='http', auth='public', csrf=False, cors='*')
    @jwt_request.middlewares('jwt')
    def me(self, **kw):
        return jwt_request.response(request.env.user.to_dict())


    @http.route('/api/http/logout', type='http', auth='public', csrf=False, cors='*')
    @jwt_request.middlewares('jwt')
    def logout(self, **kw):
        jwt_request.logout()
        return jwt_request.response()


    @http.route('/api/new_registration', type='json', auth='public', csrf=False, cors='*', methods=['POST'])
    def new_registration(self, email=None, name=None, password=None,user='user' ,**kw):
        name =request.params.get('name')
        email = request.params.get('email')
        password =request.params.get('password')
        phone_number=request.params.get('mobileno')
        
        '''
        In previous version, we use auth_signup to register an external (portal) user.
        For this demo, we use res.users.create instead, this will create an internal user
        '''
        if not is_valid_email(email):
            return jwt_request.response(status=400, data={'message': 'Invalid email address','status': 'failure'})
        if not name:
            return jwt_request.response(status=400, data={'message': 'Name cannot be empty','status': 'failure'})
        if not password:
            return jwt_request.response(status=400, data={'message': 'Password cannot be empty','status': 'failure'})

        # sign up
        try:
            if request.env['res.users'].sudo().search([('login', '=', email)]):
                return jwt_request.response(status=400, data={'message': 'Email address is already exist','status': 'failure'})

            user = request.env['res.users'].sudo().create({
                'login': email,
                'password': password,
                'name': name,
                'email': email, 
            })
            user = request.env['res.users'].sudo().search([('login', '=', email)])
            if request.env['res.users'].sudo().search([('login', '=', email)]):
                #update mobile number in res partner
                partner = request.env['res.users'].sudo().search_read([('id','=',user.id)],fields=['partner_id'])
                partner_id = partner[0]['partner_id'][0]
                partner = request.env['res.partner'].sudo().browse(int(partner_id)).write({'mobile':phone_number})
                # create token
                token = jwt_request.create_token(user)
                return {
                    'message':'Successfully Login',
                     'status':'success',
                    'user': user.to_dict(),
                    'accessToken': token,
                    'data': {
                    'email':user['email'],
                    'name':user['name'],
                    'partner_id':partner_id,
                    }
                    
                }
        except Exception as e:
            _logger.error(str(e))
            return jwt_request.response_500({
                'message': 'Server error'
            })


    @http.route('/api/http/signup', type='http', auth='public', csrf=False, cors='*', methods=['POST'])
    def register(self, email=None, name=None, password=None, **kw):
        '''
        Sign up using auth_signup modules
        '''
        if not is_valid_email(email):
            return jwt_request.response(status=400, data={'message': 'Invalid email address'})
        if not name:
            return jwt_request.response(status=400, data={'message': 'Name cannot be empty'})
        if not password:
            return jwt_request.response(status=400, data={'message': 'Password cannot be empty'})

        # sign up
        try:
            model = request.env['res.users'].sudo()
            signup = getattr(model, 'signup')
            if signup:
                if request.env['res.users'].sudo().search([('login', '=', email)]):
                    return jwt_request.response(status=400, data={'message': 'Email address is not available'})
                data = {
                    'login': email,
                    'password': password,
                    'name': name,
                    'email': email,
                }
                # signup return a tuple (db, login, password)
                # you can use that to call jwt_request.login(login, password)
                signup(data)
                # but, we just need to retrieve the newly created user
                user = model.search([
                    ('login', '=', email)
                ])
                if user:
                    token = jwt_request.create_token(user)
                    return jwt_request.response({
                        'user': user.to_dict(),
                        'token': token
                    })
                raise Exception()
        except SignupError:
            return jwt_request.response({
                'message': 'Signup is currently disabled',
            }, 400)
        except Exception as e:
            _logger.error(str(e))
            return jwt_request.response_500({
                'message': 'Cannot create user'
            })

    def _response_auth(self, token: str):
        return jwt_request.response({
            'user': request.env.user.to_dict(),
            'token': token,
        })


        
    @http.route('/api/product_list', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def product_list(self,name=None,ids=None ,**kw):
        ids =request.params.get('id')
        product_varient = []
        partner_search = request.env['product.product'].sudo().search_read([('product_tmpl_id','=',ids)],fields=['product_template_attribute_value_ids'])
        if len(partner_search) > 1:
            for line in partner_search:
                varient_line_id = request.env['product.template.attribute.value'].sudo().search_read([('id','=',line['product_template_attribute_value_ids'])],fields=['product_attribute_value_id','attribute_id'])
                name = varient_line_id[0]['product_attribute_value_id'][1]
                datas = name.split(": ")
                value = request.env['product.attribute.value'].sudo().search_read([('name','=',datas[-1])],fields=['name'])
                data = {
                    'product_id' : line['id'],
                    'attribute_id': varient_line_id[0]['attribute_id'][0],
                    'attribute_name' : varient_line_id[0]['attribute_id'][1],
                    'value_id': value[0]['id'],
                    'value_name': value[0]['name'],
                }
                product_varient.append(data)
                
        return {'attribute':product_varient}
    
    
    @http.route('/api/checklist_update', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def checklist_update_new(self):
        check_list = request.params.get('id')

        call_fuction = request.env['questions.lines.answer'].sudo().browse(int(check_list)).checklist_update()


        return  {"message":call_fuction}

    # @http.route('/api/checklist_pdf', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    # def checklist_pdf(self,name=None,ids=None ,**kw):
    #     doc = request.params.get('id')
    #     pdf = request.env.ref('appointment.report_picking_medical').sudo()._render_qweb_pdf([int(doc)])
    #     base64_data = base64.b64encode(pdf[0])
    #     name = "My Attachment"
    #     var = {
    #         'name': name,
    #         'type': 'binary', 
    #         'datas':base64_data,
    #         'store_fname': name,
    #         'res_model': 'fsm.order',
    #         'res_id':doc,
    #         'mimetype': 'application/pdf',
    #         'public': True,
    #     }

    #     create_pdf = request.env['ir.attachment'].sudo().create(var)
    #     write_otp = request.env['fsm.order'].sudo().browse(int(doc)).write({'report_attachment':create_pdf.datas})


    @http.route('/api/img_attach', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def img_attach(self,name=None,ids=None ,**kw):

        name = request.params.get('name')
        images = request.params.get('image')
        res_id = request.params.get('res_id')
        
        data = {}
        img = ast.literal_eval(images)
        file_name = ast.literal_eval(name)
        for na,image in zip(file_name,img):
            data.update({na:image})

        file_ids = []
        for file,attach in data.items():
            data = {      
            'name': file,
            'type':'binary',
            'datas': attach,
            'public':True
            }
            picking = request.env['ir.attachment'].sudo().create(data) 
            file_ids.append(picking.id)
        
        attach = {
            "attachment_id" : [[6,True,file_ids]]
        }
        request.env['questions.lines.answer'].sudo().browse(int(res_id)).write(attach)
        
        return {"message" : "updated"}

#attendance list groupby

    @http.route('/api/attendance_group', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def attendance_group(self):
        check_in = request.params.get('check_in')
        check_out = request.params.get('check_out')
        employee_id = request.params.get('employee_id')
        
        attendance_group = request.env['hr.attendance'].sudo().read_group([],
                                                                fields=['employee_id','worked_hours:sum','check_in'],
                                                                groupby=['check_in:day'])

        datas=[]
        for invoice in attendance_group:
            check_in=invoice['check_in:day']
            worked_hours=invoice['worked_hours']
            valss={'date':check_in,'worked_hours':worked_hours
                   }
            datas.append(valss)
        return  {"message":datas}
    
    @http.route('/api/visit_create', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def visit_create(self):
        vist = request.params.get('id')

        call_fuction = request.env['fsm.order'].sudo().browse(int(vist)).vist_seq()
        fsm_name = request.env['fsm.order'].sudo().search_read([('id','=',vist)],fields=['name'])
        data = {
            'log_date' : datetime.datetime.now(),
            'service_order_id' : vist,
            'staged' : 1
        }
        log = request.env['service.order.log'].sudo().create(data)

        return  {"message":fsm_name}
    
    
    @http.route('/api/post_log', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def post_log(self):
        service_id = request.params.get('id')
        stage_id = request.params.get('stage_id')
        
        data = {
            'log_date' : datetime.datetime.now(),
            'service_order_id' : service_id,
            'staged' : stage_id
        }
        log = request.env['service.order.log'].sudo().create(data)
        fsm = request.env['fsm.order'].sudo().search_read([('id','=',service_id)],fields=['users_id','person_id'])
        person_id = request.env['fsm.person'].sudo().search_read([('id','=',fsm[0]['person_id'][0])],fields=['users_id'])
        user = person_id[0]['users_id'][0]
        request.env['fsm.order'].sudo().browse(service_id).write({'users_id':user})
        count = request.env['service.order.log'].sudo().search_count([('service_order_id','=',service_id)])
        request.env['fsm.order'].sudo().browse(service_id).write({'service_log_count':count})
        return {'message':'done'}
        
        


    @http.route('/api/notifi_trigger', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def notifi_trigger(self,name=None,ids=None ,**kw):
        res_users = request.params.get('res_users')
        assigned_user = request.params.get('assigned_user')
        notify_id = request.params.get('id')
        status = request.params.get('status_id')
        ticket_id = request.params.get('fsm_order')
        content = request.params.get('descrption')
        key = []
        
        if status == "new":
            
            header = "Ticket Created"
            user_key = request.env['one.signal.master'].sudo().search_read([('user_id','=',res_users)])
            key.append(user_key[0]['key'])
            
        elif status == "assigned":
            header = "Ticket Assigned"
            user_assigned_key = request.env['one.signal.master'].sudo().search_read([('user_id','=',assigned_user)])
            key.append(user_assigned_key[0]['key'])
        elif status == "complete":
            user_key = request.env['one.signal.master'].sudo().search_read([('user_id','=',res_users)])
            if user_key:
                key.append(user_key[0]['key'])
            user_assigned_key = request.env['one.signal.master'].sudo().search_read([('user_id','=',assigned_user)])
            if user_assigned_key:
                key.append(user_assigned_key[0]['key'])
            header = "Ticket Completed"
            
        
        url = "https://onesignal.com/api/v1/notifications"
        
        payload = {
            "include_player_ids": key,
            "app_id":"95e18350-f043-42e2-84bf-984a751b12d0",

            "contents": {"en": content},
            "headings": {"en": header},
            "data": {"foo": "bar"},

        "name": "INTERNAL_CAMPAIGN_NAME"
        }
        headers = {
            "Authorization": "Basic NGEzNGY3Y2UtNmVjNi00YWEwLWJjMTktNmNhMjkyNDQ4NWUz",
        'Content-Type': 'application/json; charset=utf-8',
        }

        response = requests.post(url, json=payload, headers=headers)
        
        return  {"message": response.text} 
    
    @http.route('/api/expense_attach', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def expense_attach(self):
        res_id = request.params.get('res_id')
        company_id = request.params.get('company_id')
        file_data = request.params.get('files')
        file_names = request.params.get('file_name')
        file_data = ast.literal_eval(file_data)
        file_names = ast.literal_eval(file_names)

        for file,file_name in zip(file_data,file_names):
            file_data = {
                'name' : file_name,
                'type' : 'binary',
                'datas' : file,
                'res_model' : 'hr.expense',
                'res_id' : res_id,
                'public' : True,
                'company_id' : company_id
            }
            attached = request.env['ir.attachment'].sudo().create(file_data)
        return {'message' : 'file attached'}
    
    @http.route('/api/file_upload', type="json", auth="none", methods=["POST"], csrf=False, cors='*')
    def file_upload(self):
        filename = request.params.get('file_name')
        file_upload_image = request.params.get('files')
    
        return {'message' : file_upload_image}


    @http.route('/api/magmaa/indiamart',type='http',auth='public',csrf=False, cors='*',method=['GET','POST'])
    def crm_record_creation(self,**kw):
        base_url = "https://mapi.indiamart.com/wservce/crm/crmListing/v2/"
        glusr_crm_key = "mR27E7pq4XvDT/ei4XCK7lqKpVvMlDJr"
        start_time = "07-Jul-2023 00:00:00"
        end_time = "11-Jul-2023 23:59:59"
        params = {
            "glusr_crm_key": glusr_crm_key,
            "start_time": start_time,
            "end_time": end_time
        }

        api_url = base_url + "?" + "&".join([f"{key}={value}" for key, value in params.items()])
        
        response = requests.get(api_url)
        if response.status_code == 200:
            data = response.json()
            json_data = json.dumps(data)
            response_data = data.get("RESPONSE")
            for rec in response_data :
                state_search = request.env['res.country.state'].sudo().search([('name','ilike',rec['SENDER_STATE'])],limit=1)
                values={
                    'date_open' : rec['QUERY_TIME'],
                    'contact_name' : rec['SENDER_NAME'],
                    'mobile' : rec['SENDER_MOBILE'],
                    'email_from' :rec['SENDER_EMAIL'],
                    'name' : rec['SUBJECT'],
                    'partner_name' : rec['SENDER_COMPANY'],
                    'street' : rec['SENDER_ADDRESS'],
                    'city' : rec['SENDER_CITY'],
                    'state_id' : state_search.id,
                    'zip' : rec['SENDER_PINCODE'],
                    'description' : rec['QUERY_MESSAGE'],
                    'product_requested' : rec['QUERY_PRODUCT_NAME'],
                    'type' : 'lead',
                }
                
                if request.env['crm.lead'].sudo().search([('name','ilike',rec['SUBJECT'])]) :
                    pass
                else:
                    crm_create = request.env['crm.lead'].sudo().create(values)
            return json_data
        else:
            error_msg = f"Error {response.status_code}: Failed to fetch data from the API."
            return http.Response(status=500, content_type='application/json', body=error_msg)
    