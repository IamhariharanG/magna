from odoo import api,fields,models,http
from openerp.exceptions import ValidationError
import json
import requests
from datetime import datetime,timedelta

class cronInherit(models.Model):
    _name = "cron.crm.lead"
    _rec_name = 'key_id'
    
    key_id = fields.Char(string="Key")
    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    
    def crm_record_creation(self):
        base_url = "https://mapi.indiamart.com/wservce/crm/crmListing/v2/"
        orm_search = self.search([],limit=1)
        glusr_crm_key = orm_search.key_id
        end_time = datetime.now()
        start_time_now = end_time - timedelta(days=1)
        et = start_time_now.replace(hour=23, minute=59, second=59)
        # new_end_time = end_time + timedelta(hours=5, minutes=30)
        formatted_end_time = et.strftime('%d-%b-%Y %H:%M:%S')
        start_time = end_time - timedelta(days=1)
        st = start_time.replace(hour=0, minute=0, second=0)
        formatted_start_time = st.strftime('%d-%b-%Y %H:%M:%S')
        params = {
            "glusr_crm_key": glusr_crm_key,
            "start_time": formatted_start_time,
            "end_time": formatted_end_time
        }

        api_url = base_url + "?" + "&".join([f"{key}={value}" for key, value in params.items()])
        
        response = requests.get(api_url)
        if response.status_code == 200:
            data = response.json()
            json_data = json.dumps(data)
            response_data = data.get("RESPONSE")
            # raise ValidationError(str(response_data))

            for rec in response_data :
                state_search = self.env['res.country.state'].search([('name','ilike',rec['SENDER_STATE'])],limit=1)
                # raise ValidationError(rec['QUERY_TIME'])
                values={
                    'query_date' : rec['QUERY_TIME'],
                    'contact_name' : rec['SENDER_NAME'],
                    'mobile' : rec['SENDER_MOBILE'],
                    'email_from' :rec['SENDER_EMAIL'],
                    'name' : rec['SUBJECT'],
                    'partner_name' : rec['SENDER_COMPANY'],
                    'street' : rec['SENDER_ADDRESS'],
                    'city' : rec['SENDER_CITY'],
                    'state_id' : state_search.id,
                    'zip' : rec['SENDER_PINCODE'],
                    'message' : rec['QUERY_MESSAGE'],
                    'product_requested' : rec['QUERY_PRODUCT_NAME']
                }
                

                crm_create = self.env['crm.lead'].create(values)

        else:
            error_msg = f"Error {response.status_code}: Failed to fetch data from the API."
            return http.Response(status=500, content_type='application/json', body=error_msg)